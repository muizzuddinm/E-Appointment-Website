<?php
  include "connect.php"; 
?>

<style>

  @import url('https://fonts.googleapis.com/css?family=Muli&display=swap');
  @import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');
  
  * {box-sizing: border-box}
  body {font-family: Verdana, sans-serif; margin:0}
  
  
  /* Background Image  
  .bg-image {
  background-image: url("assets/images/bg2.png");
  background-color: white;
  height: 892px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
  } */
  
  
  /* Hide Scrollbar */
  ::-webkit-scrollbar {
  display: none;
  }
  
  h4{
    font-family: "Barlow";
    font-size: 20px;
  }
  
  /* Form */
  
  form {border: 3px solid #f1f1f1;}
  
  
  input[type=text], input[type=password] {
    width: 80%;
    padding: 12px 20px;
    margin: 8px 10px;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }
  
  div#box {
    border    : 5px solid lightgrey;
    padding   : 45x 15px;
    width     : 800px;
  }
  
  button {
    background-color: #2c3973;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
  }
  
  button:hover {
    opacity: 0.8;
  }
  
  .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
  }
  
  <!--.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
  }-->
  
  img.avatar {
    width: 80%;
    border-radius: 0%;
  }
  
  .container {
    padding: 16px;
  }
  
  span.psw {
    float: right;
    padding-top: 16px;
  }
  
  @media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
  }
  
  label{
    color:Black;
    font-size: 18px;
    font-family: Verdana, sans-serif;
  }
  
  button{
    font-size: 18px;
    font-family: Verdana, sans-serif;
  }
  
  input{
    font-family: Verdana, sans-serif;
    background: rgba(255, 255, 255, 0.6);
    color:black;
    border-radius: 5px;
  }

  .data {
    display: none;
    }

.g-signin2 {
    position: 
    top: 20%;
    left: 50%;
    margin-top: 10px;
    margin-left: -50px;
    }
  
  /* End of form */
  
  </style>
  <!DOCTYPE html>
  <html>
  <head>
  <link rel="stylesheet" href="css/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <link rel="stylesheet" href="index.css">
    </head>
    <body>
    <script src="index.js" async defer></script>
    <script src="https://apis.google.com/js/platform.js" async defer></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8"
        crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
    <!-- Background Image -->
      <div class="bg-image"><br>
  
        <h1 style="color:#2c2c2e; font-family: 'Muli'; font-size: 40px;"><center>Welcome to Student page!</center></h1>
        <div class="desc" style="margin: 0px 200px">
        </div>
  
        <center>
          <div id = 'box' style="background: rgba(240, 240, 240, 0.3); border-radius: 20px">
            <form action="login2.php" method="post" style="border-radius: 20px;">
              <div class="imgcontainer">
                <img src="images/uitm.png" alt="Avatar" class="avatar">
              </div>
              <div class="container">
                <table width = '100%' >
                  <tr>
                    <td align = 'right'>
                      <label for="uname"><b>Student ID</b></label>
                    </td>
                    <td>
                      <input type="text" placeholder="Enter ID" name="sID" required>
                    </td>
                  </tr>
                  <tr>
                    <td align = 'right'>
                      <label for="psw"><b>Password</b></label>
                    </td>
                    <td>
                      <input type="password" placeholder="Enter Password" name="psw" required>
                    </td>
                  </tr>   
                </table>
                <button type="submit" style="border-radius: 20px;">Login</button>
                <font color = "red"> 
                <?php
                  if(isset($_SESSION["error"])){
                    echo $_SESSION["error"];
                  }?>
                </font><br> 
               
                  <div class="g-signin2" data-onsuccess="onSignIn"></div>
                <meta name="google-signin-client_id" content="787827017221-bihsbob1r8gq3eu448848m7jpbd13lbc.apps.googleusercontent.com">
                <label><input type="checkbox" value="lsRememberMe" id="rememberMe"> <label for="rememberMe">Remember me</label>
            </form>
          </div> <!-- div box -->
        </center>
                  
      </div> <!-- div Image -->
    </body> <!-- End of body -->
  </html> <!-- End of html -->
  
  <script>
    function reloadNavbar() 
    {
      top.frames['header'].location.href = 'Navbar.php';
    }
    reloadNavbar();
  </script>
 <script src="https://apis.google.com/js/platform.js" async defer></script>