<!DOCTYPE html>
<html>
<head>
<title>Edit Profile</title>
<style>

@import url('https://fonts.googleapis.com/css?family=Muli&display=swap');
@import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');

* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #752ba6;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a#navbar-r:hover {
  background-color: #bf00ff;
  border-radius: 10px;
}

.profileDivOuter {
  
  margin-right: 100px;
}
.tableDiv {
  float:right;
  align:center;
  border: 1px outset #865d9e;
  background-color:rgba(241,231,254,1);    
  text-align: center;
   margin-top:30px;
  margin-bottom: 20px;
  margin-right: 8%;
  margin-left: 300px;
 position: absolute;
}


.tableDiv tr{
  border: 1px solid #ddd;
  padding: 8px;

}

.tableDiv th{
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}


.tableDiv td {
  border: 1px solid #ddd;
 padding: 8px 100px;
}

.myTable { 
		table-layout:fixed ;
		width: 80% ;
		background: rgba(240, 240, 240, 0.8); 
		border-radius: 20px 20px 0px 0px;
		font-family: Verdana, sans-serif;
		font-size: 15px;
		color:white;
		text-align: center;
	}
	
	.myTable th { 
    font-family: Verdana, sans-serif;
		font-size: 20px;
		height: 30px;
		letter-spacing:0.05em;
		background-color:#8937b8;
		color:white;
		text-align: center;
    overflow-wrap: break-word;
		word-wrap: break-word;
    border: 1px solid #ddd;
    padding: 20px 20px;
    padding:5px;
		border:1px solid #BDB76B; 
	}
	
	.myTable td { 
    padding:5px;
		border:1px solid #BDB76B; 
    font-size: 15px;
		overflow-wrap: break-word;
		word-wrap: break-word;
		text-align: center;
		color:black;
    background-color:#dddcde;
    border: 1px solid #ddd;
    
 padding: 20px 20px;

	}

  .butang{

  background-color: #99aabb;
  color: white;
  padding: 6px 10px;
  border: none;
  border-radius: 2px;

  }

  .butang2{
  
    background-color: #99aabb;
  color: white;
  padding: 6px 10px;
  border: none;
  border-radius: 2px;
  }
  .butang:hover{
    background-color: #59f07c;
    color: black;
  }
  .butang2:hover{
    background-color: #f74d4d;
    color: black;
  }

</style>
</head>
<body>
  <?php include "connect.php";
  
  $stud_id = $_SESSION["userID"];
  $sql = "SELECT * FROM student WHERE username ='$stud_id'";
  $result = mysqli_query($connect,$sql);  
  ?>
 
<div class="profileDivOuter">
<?php 		
	include "sidenav.php";
?>
  <div class="tableDiv">
    
  <h2 text-align="left"; style="padding: 10px"; > Edit Profile</h2>
  <p>This section is to edit the personal details.</p>
  <center>
  <table class="myTable">
   
  <?php
    $result = mysqli_query($connect,$sql);
    $data = mysqli_fetch_assoc($result);
    ?>
                

        <div class="container">
        <form name="edit" method="POST" action="updateProfile.php">

              <tr>
              <th style='border-radius: 20px 0px 0px 0px'>Student ID</th>
              <td style='border-radius: 0px 20px 0px 0px'><input  type="text" id="sID" name="sID" placeholder="Enter ID" value="<?php echo $data["username"]?>"disabled> </input></td>
              <input  type="hidden" id="sID" name="sID" placeholder="Enter ID" value="<?php echo $data["username"]?>"> </input>
              </tr>

              <tr>
              <th>Student First Name</th>
              <td><input type="text" id="FName" name="FName" placeholder="Enter First Name" value="<?php echo $data["firstname"]?>"disabled> </input></td>
              <input type="hidden" id="FName" name="FName" placeholder="Enter First Name" value="<?php echo $data["firstname"]?>"> </input>
              </tr>

              <tr>
              <th>Student Last Name</th>
              <td><input type="text" id="LName" name="LName" placeholder="Enter Last Name" value="<?php echo $data["lastname"]?>"disabled> </input></td>
              <input type="hidden" id="LName" name="LName" placeholder="Enter Last Name" value="<?php echo $data["lastname"]?>"> </input>
              </tr>

              <tr>
              <th>Student Programme</th>
              <td><input type="text" id="sProgramme" name="sProgramme" placeholder="Enter Programme" value="<?php echo $data["programme"]?>"disabled> </input></td>
              <input type="hidden" id="sProgramme" name="sProgramme" placeholder="Enter Programme" value="<?php echo $data["programme"]?>"> </input>
             </tr>

             <tr>
             <th>Student Contact</th>
             <td><input type="text" id="sContact" name="sContact" placeholder="Enter Contact" value="<?php echo $data["contact"]?>"> </input></td>
             </tr>
             <tr>
             <th>Email</th>
             <td><input type="text" id="sEmail" name="sEmail" placeholder="Enter Email" value="<?php echo $data["email"]?>"> </input></td>
             </tr>

             <tr>
             <th>Education Email</th>
             <td><input type="text" id="eduEmail" name="eduEmail" placeholder="Enter Education Email" value="<?php echo $data["education_email"]?>"disabled> </input></td>
             <input type="hidden" id="eduEmail" name="eduEmail" placeholder="Enter Education Email" value="<?php echo $data["education_email"]?>"> </input>
             </tr>

             <tr>
             <th>Muet</th>
             <td><input type="text" id="sMuet" name="sMuet" placeholder="Enter Muet Grade" value="<?php echo $data["muet"]?>" disabled> </input></td>
             <input type="hidden" id="sMuet" name="sMuet" placeholder="Enter Muet Grade" value="<?php echo $data["muet"]?>" > </input>
             </tr>

             <tr>
             <th style='border-radius: 0px 0px 0px 20px'>Advisor</th>
              <td style='border-radius: 0px 0px 20px 0px'><input  type="text" id="sAdvisor" name="sAdvisor" placeholder="Enter Advisor Name" value="<?php echo $data["advisor"]?>"disabled> </input></td>
              <input type="hidden" id="sAdvisor" name="sAdvisor" placeholder="Enter Advisor Name" value="<?php echo $data["advisor"]?>"> </input>
             </tr>
            <tr>
            
 
  </table>
  <br>
  <input type="button" class="butang2" onclick="history.back();" value='Back'>
            <input type="submit" class="butang" value="Submit"> <br><br>`
          </div>
           <br><br>
          </form>   
  <br>
</center>

  
  
  
  

  </div>
</div>

</body>
</html>



