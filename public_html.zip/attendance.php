<!DOCTYPE html>
<html>
<body>

<p>Click on the "Choose File" button to upload a file:</p>
<?php 
include "sidenav.php";
?>
<div>
<form action="/action_page.php">
  <input type="file" id="myFile" name="filename">
  <input type="submit">
</form>
</div>
</body>
</html>
