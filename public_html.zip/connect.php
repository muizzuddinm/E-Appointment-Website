<!-- Connection to Database -->
<?php
 
 ini_set("display_errors","1");
 ini_set("display_startup_errors","1");
 error_reporting(E_ALL);
 
 $user = 'u124699175_muiz';
 $host = 'localhost';
 $pass ='Ayamgoreng123';

 $connect = mysqli_connect($host,$user,$pass);
 $dbname = 'u124699175_db';

 $seldb = mysqli_select_db($connect,$dbname);

 if(session_status() === PHP_SESSION_NONE)
	{
		session_start();
	}
	

?>