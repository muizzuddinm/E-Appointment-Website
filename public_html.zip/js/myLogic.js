var keycloak = new Keycloak();

function initKeycloak() {
    keycloak.init({onLoad: 'login-required'}).then(function() {
        constructTableRows(keycloak.idTokenParsed);
        pasteToken(keycloak.token);
    }).catch(function() {
        alert('failed to initialize');
    });
}

function constructTableRows(keycloakToken) {
    document.getElementById('row-username').innerHTML = keycloakToken.student_id;
    document.getElementById('row-name').innerHTML = keycloakToken.name;
    document.getElementById('row-programme').innerHTML = keycloakToken.programmee;
    document.getElementById('row-email').innerHTML = keycloakToken.email;
    document.getElementById('row-education_email').innerHTML = keycloakToken.eduemail;
    document.getElementById('row-muet').innerHTML = keycloakToken.muet;
    document.getElementById('row-advisor').innerHTML = keycloakToken.advbisor;
}

function pasteToken(token){
    document.getElementById('ta-token').value = token;
    document.getElementById('ta-refreshToken').value = keycloak.refreshToken;
}

var refreshToken = function() {
    keycloak.updateToken(-1)
    .then(function(){
        document.getElementById('ta-token').value = keycloak.token;
        document.getElementById('ta-refreshToken').value = keycloak.refreshToken;
    });
}

var logout = function() {
    keycloak.logout({"redirectUri":"http://localhost:9091/logout.php"});
}