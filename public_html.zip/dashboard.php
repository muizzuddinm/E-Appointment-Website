<?php

session_start();

if(isset($_SESSION['access_token'])){ 
 $userData=$_SESSION['user_data'];

}else{
  header("location:login-page.php");
}
?>

<p>Oauth id -</p>
<p>Oauth Provider -</p>
<p>First Name- </p>
<p>Last Name - </p>
<p>Email - </p>
<p><a href="logout.php">Logout</a></p>
