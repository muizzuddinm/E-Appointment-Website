<!DOCTYPE html>
<html>
<head>
<title>Edit Profile</title>
<style>

@import url('https://fonts.googleapis.com/css?family=Muli&display=swap');
@import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');

* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #752ba6;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a#navbar-r:hover {
  background-color: #bf00ff;
  border-radius: 10px;
}

.profileDivOuter {
  
  margin-right: 100px;
}
.tableDiv {
  float:right;
  align:center;
  border: 1px outset #865d9e;
  background-color:rgba(241,231,254,1);    
  text-align: center;
   margin-top:100px;
  margin-bottom: 20px;
  margin-right: 8%;
  margin-left: 300px;
 position: absolute;
}


.tableDiv tr{
  border: 1px solid #ddd;
  padding: 8px;

}

.tableDiv th{
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}


.tableDiv td {
  border: 1px solid #ddd;
 padding: 8px 100px;
}

.myTable { 
		table-layout:fixed ;
		width: 80% ;
		background: rgba(240, 240, 240, 0.3); 
		border-radius: 20px 20px 0px 0px;
		font-family: Verdana, sans-serif;
		font-size: 15px;
		color:black;
		text-align: center;
	}
	
	.myTable th { 
		font-family: Verdana, sans-serif;text-shadow: 1px 1px 4px black;
		font-size: 20px;
		height: 30px;
		letter-spacing:0.05em;
		background-color:#FFB450;
		color:white;
		text-align: center;
	}
	
	.myTable td, .myTable th { 
		padding:5px;
		border:1px solid #BDB76B; 
		overflow-wrap: break-word;
		word-wrap: break-word;
		text-align: center;
	}


  
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  margin:50px;
}

.left-col {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.right-col {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

.butang{

  background-color: #99aabb;
  color: white;
  padding: 6px 10px;
  border: none;
  border-radius: 2px;

}

.butang2{

  background-color: #99aabb;
color: white;
padding: 6px 10px;
border: none;
border-radius: 2px;
}
  .butang:hover{
    background-color: #59f07c;
    color: black;
  }
  .butang2:hover{
    background-color: #f74d4d;
    color: black;
  }

</style>
</head>
<body>
  <?php 
  include "connect.php";
  
  $stud_id = $_SESSION["userID"];
  $sql = "SELECT * FROM student WHERE username ='$stud_id'";
  $result = mysqli_query($connect,$sql);

  
  ?>
 
<div class="profileDivOuter">
<?php 		
	include "sidenav.php";
?>
  <div class="tableDiv">
    
  <h2 text-align="left"; style="padding: 10px"; > Book an Appointment Page</h2>
  <p>This section for student to book an appointment with the lecturer.</p>
  <center>
  <table class="myTable">
   
  <?php
    $sql1 = "select * from lecturer";
    $result = mysqli_query($connect,$sql1);
    
    ?>
                

        <div class="container">
        <form name="appointment" method="post" action="appointmentadd.php">

          <div class="row">
            <div class="left-col">
              <label for="sID">Student ID:</label>
            </div>
            <div class="right-col">
              <input readonly type="text"  name="studID" placeholder="Enter Student ID" required value="<?php echo $stud_id;?>"/>
            </div>
          </div>

          <div class="row">
            <div class="left-col">
              <label for="lName">Leturer Name:</label>
            </div>
            <div class="right-col">
              <select id="lectname" name="lectname">
              <option value='' hidden>Select one</option>
                <?php
                                      
                    while($Trow = mysqli_fetch_array($result)) {
                      echo '<option value='.$Trow['lect_id'].'>'.$Trow['lect_name'].'</option>';
                    }
                ?>
              </select>
              </div>
          </div>
              <div class="row">
                <div class="left-col">
                <label for="date">Date:</label>
              </div>
              <div class="right-col">
              <input type="date" id="date" name="appointmentdate">
              </div>
            </div>
              </div>
            
        <br>
        
            
 
  </table>
  <br><br>
  <input type="button" class="butang2" onclick="history.back();" value='Cancel'>
            <input type="submit" class="butang" value="Submit"> <br><br>
          </div>
           <br><br>
          </form>  
  <br><br><br>
</center>

  
  
  
  

  </div>
</div>

</body>
</html>



