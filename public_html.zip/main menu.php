<?php
	include "connect.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>Main Menu</title>
<style>

@import url('https://fonts.googleapis.com/css?family=Muli&display=swap');
@import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');

* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #752ba6;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a#navbar-r:hover {
  background-color: #bf00ff;
  border-radius: 10px;
}

.profileDivOuter {
  
  margin-right: 100px;
}
.tableDiv {
  float:right;
  align:center;
  border: 1px outset #865d9e;
  background-color:rgba(241,231,254,1);    
  text-align: center;
   margin-top:30px;
  margin-bottom: 20px;
  margin-right: 8%;
  margin-left: 300px;
 position: absolute;
}

.tableDiv tr{
  border: 1px solid #ddd;
  padding: 20px;

}

.tableDiv th{
  border: 1px solid #ddd;
  padding: 20px;
  text-align: left;
}


.tableDiv td {
  border: 1px solid #ddd;
 padding: 8px 650px;
 
}

.btnEdit{
  align:right;
margin-left:1600px;
}

.profile tr:hover
{
  background-color: #ddd;
}

.myTable { 
		table-layout:fixed ;
		width: 80% ;
		background: rgba(240, 240, 240, 0.8); 
		border-radius: 20px 20px 0px 0px;
		font-family: Verdana, sans-serif;
		font-size: 15px;
		color:white;
		text-align: center;
	}
	
	.myTable th { 
		font-family: Verdana, sans-serif;
		font-size: 20px;
		height: 30px;
		letter-spacing:0.05em;
		background-color:#8937b8;
		color:white;
		text-align: center;
    overflow-wrap: break-word;
		word-wrap: break-word;
    border: 1px solid #ddd;
    padding: 20px 20px;
    padding:5px;
		border:1px solid #BDB76B; 
	
	}
	
	.myTable td { 
		padding:5px;
		border:1px solid #BDB76B; 
    font-size: 15px;
		overflow-wrap: break-word;
		word-wrap: break-word;
		text-align: center;
		color:black;
    background-color:#dddcde;
    border: 1px solid #ddd;
    
 padding: 20px 20px;
	}
  

</style>
</head>
<body>
  
  <?php 
  $stud_id = $_SESSION["userID"];
  $sql = "SELECT * FROM student WHERE username ='$stud_id'";
  $result = mysqli_query($connect,$sql);
  
  ?>
 
<div class="profileDivOuter">

  <?php
      include "sidenav.php";
  ?>

  <div class="tableDiv">
    
  <h2 text-align="left"; style="padding: 10px"; > Student Profile</h2>
  <p>This section will show the student's profile.</p>
  <center>
  <table class="myTable">
			

				
					<?php
					if(mysqli_num_rows($result) > 0) 
					{
						foreach($result as $row) { 
							$stud_id = $row['username'];
							$studentfirstname = $row['firstname'];
              $studentlastname = $row['lastname'];
              $sprograme =$row['programme'];
							$scontact = $row['contact'];
							$semail = $row['email'];
							$eduemail = $row['education_email'];
							$smuet = $row['muet'];
              $sadvisor = $row['advisor'];
							

             
              echo"<tr>";
              echo "<th style='border-radius: 20px 0px 0px 0px'>Student ID</th>";
              echo"<td style='border-radius: 0px 20px 0px 0px'>$stud_id</td>";
              echo"</tr>";

              echo"<tr>";
              echo" <th>Student First Name</th>";
              echo"<td>$studentfirstname</td>";
              echo"</tr>";

              echo"<tr>";
              echo" <th>Student Last Name</th>";
              echo"<td>$studentlastname</td>";
              echo"</tr>";

              echo"<tr>";
              echo"<th>Student Programme</th>";
              echo"<td>$sprograme</td>";
              echo"</tr>";

              echo"<tr>";
              echo"<th>Student Contact</th>";
              echo"<td>$scontact</td>";
              echo "</tr>";

              echo "<tr>";
              echo "<th>Email</th>";
              echo"<td>$semail</td>";
              echo "</tr>";

              echo "<tr>";
              echo"<th>Education Email</th>";
              echo"<td>$eduemail</td>";
              echo"</tr>";

              echo"<tr>";
              echo"<th>Muet</th>";
              echo"<td>$smuet</td>";
              echo"</tr>";

              echo"<tr>";
              echo" <th style='border-radius: 0px 0px 0px 20px'>Advisor</th>";
              echo"<td style='border-radius: 0px 0px 20px 0px'>$sadvisor</td>";
              echo"</tr>";
              

							/*echo"<th style='color:white;'>";
              echo"<tr>";
							echo"<tr>$stud_id</tr>";
							echo"<tr>$studentname</tr>";
							echo"<tr>$scontact</tr>";
							echo"<tr>$semail</tr>";
							echo"<tr>$eduemail</tr>";
							echo"<tr>$smuet</tr>";
              echo"<tr>$sadvisor</tr>";
					
							echo"</th>";*/
						}
					}
					//echo $_SESSION['userID'];
					mysqli_close($connect);
					?>
				
			</table>
      <br><br><br>
      </center>
 
  
  
  
  

  </div>
</div>

</body>
</html>



