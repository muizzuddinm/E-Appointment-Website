<?php

 // Start session
require_once('../login.php');

include "../connect.php";
 $db=$connect;
 $tableName='users';

function user_data($data,$tableName){

        $existUser=exist_user($data, $tableName);
        return $existUser;
  }

  function  exist_user($data,$tableName){
       global $db;
       $existQuery="SELECT * from ".$tableName." WHERE oauth_provider='".$data['oauth_provider']."' AND oauth_uid='".$data['oauth_uid']."'";
      $existResult=$db->query($existQuery);
      if ($existResult->num_rows> 0) {
          
          update_user($data,$tableName);
      }else{
          insert_user($data, $tableName);
      }
    $fetchUserData = $existResult->fetch_assoc(); 
    return $fetchUserData;
  }

  function update_user($data,$tableName){
      
     global $db;
     $columnsValues = ''; 
     $num = 0; 
     foreach($data as $column=>$value){ 
                    
             $comma = ($num > 0)?', ':''; 
             $columnsValues.=$column." = ".$value.$comma;
             $num++; 
      } 

      $updateQuery="UPDATE".$tableName." SET ".$columnsValues." WHERE oauth_provider='".$data['oauth_provider']."' AND oauth_uid='".$data['oauth_uid']."'";
      
      $updateResult=$db->query($updateQuery);
      if($updateResult){
      return "Error: " . $updateResult . "<br>" . $db->error;
      }
  }

function insert_user($data,$tableName){
       
     global $db;

     $tableColumns = $userValues = ''; 
     $num = 0; 
     foreach($data as $column=>$value){ 
          $comma = ($num > 0)?', ':''; 
          $tableColumns .= $comma.$column; 
          $userValues  .= $comma."'".$value."'"; 
          $num++; 
      } 
    $insertQuery="INSERT INTO ".$tableName."  (".$tableColumns.")VALUES(".$userValues.")";
    $insertResult=$db->query($insertQuery);
    if($insertResult){
     return "Error: " . $insertQuery . "<br>" . $db->error;
    }

}
?>