<?php
require('api-setting.php');
require('user-data.php');
if(isset($_SESSION['access_token'])){
   $googleClient->setAccessToken($_SESSION['access_token']);
}else if(isset($_GET['code'])) {
   $googleClient->authenticate($_GET['code']); 
   $_SESSION['access_token'] = $googleClient->getAccessToken(); 
    
}else{
  header('location:../index.php');
  exit();
}
 
if(isset($_SESSION['access_token'])){ 
    // Get user profile data from google 
    $userInfo = $googleService->userinfo->get(); 
     
   $id= !empty($userInfo['id'])? $userInfo['id']:'';
   $firstName= !empty($userInfo['given_name'])? $userInfo['given_name']:''; 
   $lastName= !empty($userInfo['family_name'])? $userInfo['family_name']:''; 
   $email= !empty($userInfo['email'])?$userInfo['email']:''; 
    // Getting user profile info 
  $data = [
     'oauth_uid'  => $id,
     'first_name' => $firstName,
     'last_name'  => $lastName,
     'email'      => $email,
     'gender'     => $gender,
     'picture'    => $picture
  ];
   
    // Insert or update user data to the database 
    $data['oauth_provider'] = 'google'; 
    $userData = user_data($data,$tableName);
    // logged in user data
    $_SESSION['user_data']= $userData; 
     header('Location: ' . filter_var($dashboardPageURL, FILTER_SANITIZE_URL)); 
  
}
?>