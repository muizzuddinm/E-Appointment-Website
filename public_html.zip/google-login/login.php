<?php

require('api-setting.php');

if(isset($_SESSION['access_token'])){ 

   header('Location: ' . filter_var($googleRedirectURL, FILTER_SANITIZE_URL)); 
   exit();
}
    $authURL = $googleClient->createAuthUrl(); 
      //google Login Button
    $googleLoginLink= filter_var($authURL, FILTER_SANITIZE_URL);
?>