<?php

 $dashboardPageURL='https://muizfyp.online/google-login/dashboard.php';

 // Google API configuration
 $googleClientID="787827017221-bihsbob1r8gq3eu448848m7jpbd13lbc.apps.googleusercontent.com";
 $googleClientSecret="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";
 $googleRedirectURL="https://muizfyp.online/google-login/callback.php";
 $loginTo="Login to muizfyp.online";

 // Include Google API client library
 require_once 'google-plus-api-client-master/src/Google_Client.php';
 require_once 'google-plus-api-client-master/src/auth/Google_Oauth2.php';
// Call Google API
$googleClient = new Google_Client();

$googleClient->setApplicationName($loginTo);
$googleClient->setClientId($googleClientID);
$googleClient->setClientSecret($googleClientSecret);
$googleClient->setRedirectUri($googleRedirectURL);

$googleService = new Google_Oauth2Service($googleClient);
?>
