<!DOCTYPE html>
<html>
<head>
<title>Edit Profile</title>
<style>

@import url('https://fonts.googleapis.com/css?family=Muli&display=swap');
@import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');

* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #752ba6;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a#navbar-r:hover {
  background-color: #bf00ff;
  border-radius: 10px;
}

.profileDivOuter {
  
  margin-right: 100px;
}
.tableDiv {
  float:right;
  align:center;
  border: 1px outset #865d9e;
  background-color:rgba(241,231,254,1);    
  text-align: center;
   margin-top:100px;
  margin-bottom: 20px;
  margin-right: 8%;
  margin-left: 300px;
 position: absolute;
}


.tableDiv tr{
  border: 1px solid #ddd;
  padding: 8px;

}

.tableDiv th{
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}


.tableDiv td {
  border: 1px solid #ddd;
 padding: 8px 100px;
}

.myTable { 
	table-layout:fixed ;
		width: 80% ;
		background: rgba(240, 240, 240, 0.8); 
		border-radius: 20px 20px 0px 0px;
		font-family: Verdana, sans-serif;
		font-size: 15px;
		color:white;
		text-align: center;
	}
	
	
	.myTable th { 
		font-family: Verdana, sans-serif;
		font-size: 20px;
		height: 30px;
		letter-spacing:0.05em;
		background-color:#8937b8;
		color:white;
		text-align: center;
        overflow-wrap: break-word;
		word-wrap: break-word;
        border: 1px solid #ddd;
        padding: 20px 20px;
        padding:5px;
		border:1px solid #BDB76B; 
	}
	
	.myTable td { 
		padding:5px;
		border:1px solid #BDB76B; 
        font-size: 15px;
		overflow-wrap: break-word;
		word-wrap: break-word;
		text-align: center;
		color:black;
        background-color:#dddcde;
        border: 1px solid #ddd;
        padding: 20px 20px;
    }

  
    .butang{
    background-color: #99aabb;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;

    }
    .butang:hover{
    background-color: #59f07c;
    color: black;
    }

</style>
</head>
<body>
  <?php include "connect.php";
  
  
  
  ?>
 
<div class="profileDivOuter">
<?php 		
	include "sidenav.php";
?>
  <div class="tableDiv">
    
  <h2 text-align="left"; style="padding: 10px"; > Book an Appointment Page</h2>
  <p>This section for student to book an appointment with the lecturer.</p>
  <center>
  <table class="myTable">
  <input type="submit" onclick='location.href="appointment.php"' class="butang" value="Make an Appointment"> <br><br>`
  <?php

    $stud_id = $_SESSION["userID"];
    $sql = "SELECT * FROM appointment 
    LEFT JOIN lecturer
    ON appointment.lect_id = lecturer.lect_id
    WHERE student_id ='$stud_id'";

    $result = mysqli_query($connect,$sql);

    if (mysqli_num_rows($result) > 0)
    {
        foreach($result as $row) {
            $lID = $row['lect_id'];
            $lname = $row['lect_name'];
            $appointdate = $row['date'];
        }

        echo"<th>Appointment ID</td>";
        echo"<th>Lecturer Name</td>";
        echo"<th>Appointment Date</td>";
        echo"<tr>";
        echo"<td>$lID</td>";
        echo"<td>$lname</td>";
        echo"<td>$appointdate</td>";
    
    }

    ?>

  </table>
  <br><br>
           
          </div>
           <br><br>
          </form>   
  <br><br><br>
</center>

  
  
  
  

  </div>
</div>

</body>
</html>



