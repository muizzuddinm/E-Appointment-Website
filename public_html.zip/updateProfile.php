<?php
include "connect.php";

$id = $_POST['sID'];
$firstname = $_POST['FName'];
$lastname = $_POST['LName'];
$sprogramme = $_POST['sProgramme'];
$scontact = $_POST['sContact'];
$semail = $_POST['sEmail'];
$eduemail = $_POST['eduEmail'];
$smuet = $_POST['sMuet'];
$advisor = $_POST['sAdvisor'];

echo $id;
echo $firstname;
echo $lastname;
echo $sprogramme;
echo $scontact;
echo $semail;
echo $eduemail;
echo $smuet;
echo $advisor;


$sql="UPDATE student SET firstname='$firstname', lastname='$lastname', programme='$sprogramme',
contact='$scontact',email='$semail',education_email='$eduemail',muet='$smuet',
muet='$smuet' WHERE username='$id'";
		
if(mysqli_query($connect,$sql))
	{
		$_SESSION["userID"] = $id;
		print '<script> alert("Profile has been updated"); </script>';
		print '<script> window.location.assign("main menu.php"); </script>';
	}
	else
	{
		print '<script> alert("Error"); </script>';
		print '<script> window.location.assign("editProfile.php"); </script>';
	}
	mysqli_close($connect);
?>	