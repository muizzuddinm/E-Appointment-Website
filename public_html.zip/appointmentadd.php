<?php
  include "connect.php";

  if($_SERVER['REQUEST_METHOD'] === 'POST') {

    //$appID = $_POST['appointment_id'];
    $date = $_POST['appointmentdate'];
    //$lID = $_POST['lect_id'];
    $lname = $_POST['lectname'];
    $sID = $_SESSION["userID"];

   

    $psql = "SELECT * FROM appointment 
    LEFT JOIN lecturer on appointment.lect_id = lecturer.lect_id 
    LEFT JOIN student on appointment.student_id = student.username";
    $Pack = mysqli_fetch_assoc(mysqli_query($connect, $psql));

  

    echo $appID; 
    echo $date;
    echo $lID;
    echo $lname;
    echo $sID;

    $sql = "select * from lecturer where lect_id = '".$lID."' limit 1"; 
    $result = mysqli_query($connect,$sql);

    if(mysqli_num_rows($result) == 0){

      $register = "INSERT INTO appointment (`appointment_id`, `date`, `lect_id`, `student_id` VALUES ('$appID','$date','$lID','$lname', '$sID')";

      $exec = mysqli_query($connect,$register);

      if($exec) {
        $_SESSION['status'] = "Register Successful!";
      }

      else {
        $_SESSION['status'] = "An Error Has Occurred";
      }
    }
    else
    {
      $_SESSION['status'] = "Coach ID already exist in the database";
    }

    header("location: coachingRegister.php");
  }

?>