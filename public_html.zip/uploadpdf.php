<!DOCTYPE html>
<html>
<head>
<title>Edit Profile</title>
<style>

@import url('https://fonts.googleapis.com/css?family=Muli&display=swap');
@import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');

* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #752ba6;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a#navbar-r:hover {
  background-color: #bf00ff;
  border-radius: 10px;
}

.profileDivOuter {
  
  margin-right: 100px;
}
.tableDiv {
  float:right;
  align:center;
  border: 1px outset #865d9e;
  background-color:rgba(241,231,254,1);    
  text-align: center;
   margin-top:100px;
  margin-bottom: 20px;
  margin-right: 8%;
  margin-left: 300px;
 position: absolute;
}

.tableDiv tr{
  border: 1px solid #ddd;
  padding: 8px;

}

.tableDiv th{
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}


.tableDiv td {
  border: 1px solid #ddd;
 padding: 8px 100px;
}

.myTable { 
		table-layout:fixed ;
		width: 80% ;
		background: rgba(240, 240, 240, 0.3); 
		border-radius: 20px 20px 0px 0px;
		font-family: Verdana, sans-serif;
		font-size: 15px;
		color:black;
		text-align: center;
	}
	
	.myTable th { 
		font-family: Verdana, sans-serif;text-shadow: 1px 1px 4px black;
		font-size: 20px;
		height: 30px;
		letter-spacing:0.05em;
		background-color:#FFB450;
		color:white;
		text-align: center;
	}
	
	.myTable td, .myTable th { 
		padding:5px;
		border:1px solid #BDB76B; 
		overflow-wrap: break-word;
		word-wrap: break-word;
		text-align: center;
	}


  
    .butang{
    background-color: #99aabb;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;

    }
    .butang:hover{
    background-color: #59f07c;
    color: black;
    }

    .form-group {
        width: 1000px;
    }

    .btnRegister{

    background-color: #99aabb;
    color: white;
    padding: 6px 10px;
    border: none;
    border-radius: 2px;
    }


    .btnRegister:hover{
    background-color: #59f07c;
    color: black;
    }

</style>
</head>
<body>
  <?php include "connect.php";
  
  $stud_id = $_SESSION["userID"];
  $sql = "SELECT * FROM student WHERE username ='$stud_id'";
  $result = mysqli_query($connect,$sql);
  
  ?>
 
<div class="profileDivOuter">
<?php 		
	include "sidenav.php";
?>
  <div class="tableDiv">
    
  <h2 text-align="left"; style="padding: 10px"; > E-MC/Leaving Upload Form</h2>
  <p>This section for student to upload MC/Leaving Certificate.</p>
  <center>
  <table class="myTable">
  <br><br><br>
  <?php
    $sql = "select * from appointment";
    $result = mysqli_query($connect,$sql);
    ?>

<form method="post" enctype="multipart/form-data">                              
        <div class="form-group">
          <input type="file" name="pdf_file"
                 class="form-control" accept=".pdf"
                 title="Upload PDF"/>
        </div>
        <br>
        <div class="form-group">
          <input type="submit" class="btnRegister"
                 name="submit" value="Submit">
        </div>
   </div>
</form>


                

        
            
 
  </table>
  <br><br>
           
          </div>
           <br><br>
          </form>   
  <br><br><br>
</center>

  
  
  
  

  </div>
</div>

</body>
</html>



